function noisy_signal = awgn_generator(signal, snrdb, seedsTURNG1, seedsTURNG2)
    % Ensure SNR is within the specified range
    if ~all(snrdb >= -20 & snrdb <= 31)
        error('SNR value must be in the range of -20 to 31 dB for all elements');
    end
    %signal =0;
    % Convert to linear scale, generating the noise variance in a linear
    % scale which is later used to multiply the o/p of Gn noise with unit
    % variance
    noiseVar = 1./10.^(snrdb./10);
    
 % Generate two Gaussian random numbers
    [x0, x1] = hdlrandn(length(snrdb), seedsTURNG1, seedsTURNG2);
        
 % Gaussian random numbers to the required noise variance
    noise= sqrt(noiseVar/2) .* (x0 + 1i * x1); %noiseVar*(x0+1i*x1);
    
    
    % Add the AWGN to the input signal
    noisy_signal = signal + noise;
end

