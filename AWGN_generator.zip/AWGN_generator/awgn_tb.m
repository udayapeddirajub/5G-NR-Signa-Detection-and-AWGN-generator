
clear all; clc;close all;
hdlawgn_init;   
signal = 0; % assuming sgnal has 0dB power
latency = 0;
NofSel = 1000000;
noisy_signal = awgn_generator(signal, snrdBSimInput, seedsURNG1, seedsURNG2);
    

%sndBSimInput

% Plot PDF for Real Part of AWGN

figure;
title('PDF for Real Part of AWGN');
hold on;

histogram(real(noisy_signal(latency+1:NofSel+latency)), 500, 'Normalization', 'pdf', 'BinLimits', [-2, 2], 'FaceColor', 'blue', 'EdgeColor', 'none');
histogram(real(noisy_signal(NofSel+latency+1:end)), 500, 'Normalization', 'pdf', 'BinLimits', [-2, 2], 'FaceColor', 'yellow', 'EdgeColor', 'none');
legend('5 dB SNR','15 dB SNR');

hold off;


% Plot PDF for Imaginary Part of AWGN
figure;
title('PDF for Imaginary Part of AWGN');
hold on;
histogram(imag(noisy_signal(latency+1:NofSel+latency)), 500, 'Normalization', 'pdf', 'BinLimits', [-2, 2], 'FaceColor', 'blue', 'EdgeColor', 'none');
histogram(imag(noisy_signal(NofSel+latency+1:end)), 500, 'Normalization', 'pdf', 'BinLimits', [-2, 2], 'FaceColor', 'yellow', 'EdgeColor', 'none');
legend('5 dB SNR','15 dB SNR');
hold off;

