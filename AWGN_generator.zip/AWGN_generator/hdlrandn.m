%hdlrandn Generates Gaussian random number  
%   [x0,x1] = hdlrandn(size,s1,s2) generates two Gaussian random variables with unit variance using Box-Muller method.
%   Box-Muller method uses Tausworthe uniform random numbers generators (TURNG). 
%   Seeds of Tausworthe URNG can be specified using seedsTURNG1 and       
%   seedsTURNG2. Each Tausworthe URNG requires 3 seed values. seedsTURNG1 
%   and seedsTURNG2 should be of vector size 3.
% 

% Copyright 2020 The MathWorks, Inc.
%
function [x0,x1]=hdlrandn(size,seedsTURNG1,seedsTURNG2)
%% Validate input parameters
%  validateattributes(size, {'numeric'}, ...
%         {'real','scalar','positive','integer','nonzero','nonempty'}, ...
%         'hdlrandn','size');
% validateattributes(seedsTURNG1, {'numeric'}, ...
%         {'real','vector','integer','positive','nonempty','numel',3}, ...
%         'hdlrandn','seedsTURNG1');
% validateattributes(seedsTURNG2, {'numeric'}, ...
%         {'real','vector','integer','positive','nonempty','numel',3}, ...
%         'hdlrandn','seedsTURNG2'); 

x0=zeros(size,1);
x1=zeros(size,1);

for j=1:size
     % Use two Tausworthe uniform random number generators
     [ a,seedsTURNG1] = hdltausURNG(seedsTURNG1);
     [ b,seedsTURNG2] = hdltausURNG(seedsTURNG2);
	 
     u0_bin = dec2bin(a,32);
     u1_bin = dec2bin(b,32);
	 
	 
     u0 = bin2dec([u0_bin,u1_bin(1:16)])*(2^-48);
     u1 = double(bitand(b,65535))/2^16;
	 
     g0=sin(2*pi*double(u1));
     g1=cos(2*pi*double(u1));
	 
     e=-2*log(double(u0));
     f=sqrt(e);
	 
     x0(j)=f*g0;
     x1(j)=f*g1;  
end
