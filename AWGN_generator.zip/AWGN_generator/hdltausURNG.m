% hdltausURNG implements Tausworthe uniform random generator
% [urnOut, urnSeed] = hdltausURNG(urnSeed) generates uniform random number (urnOut).
% Input urnSeed must be a vector of size 3. 
% 

% Copyright 2020 The MathWorks, Inc.
%
function [urnOut, urnSeed] = hdltausURNG(urnSeed)

nrmlz = uint64(2^32);

val = floor(double(bitxor(mod(urnSeed(1)*8192,nrmlz),urnSeed(1)))/524288);
urnSeed(1) = bitxor(mod(bitand(urnSeed(1),4294967294)*4096,nrmlz),val);

val = floor(double(bitxor(mod(urnSeed(2)*4,nrmlz),urnSeed(2)))/33554432);
urnSeed(2) = bitxor(mod(bitand(urnSeed(2),4294967288)*16,nrmlz),val);

val = floor(double(bitxor(mod(urnSeed(3)*8,nrmlz),urnSeed(3)))/2048);
urnSeed(3) = bitxor(mod(bitand(urnSeed(3),4294967280)*131072,nrmlz),val);

urnOut = bitxor(bitxor(urnSeed(1),urnSeed(2)),urnSeed(3));
end
