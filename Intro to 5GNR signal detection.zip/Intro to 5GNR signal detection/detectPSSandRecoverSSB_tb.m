
%Setting up the input signal data required

rx = load('waveformIntroSignalDetection.mat');
rxWaveform = rx.waveform;
rxWaveform_scaled = rxWaveform*(0.95/(max(abs(rxWaveform))));   % Scale input waveform to have max abs value of 0.95
Fs_rxWaveform = rx.sampleRate;
ssbPattern = rx.ssbBlockPattern;
Lmax = rx.L_max;

%%
% Plot spectrogram of rxWaveform.
figure;
spectrogram(rxWaveform(:,1), ones(512,1), 0, 512, 'centered', Fs_rxWaveform, 'yaxis', 'MinThreshold', -130);
title('Signal Spectrogram');

%%
% Set SSB subcarrier spacing (|scsSSB|) based on the SSB pattern
% (|ssbPattern|). SSB pattern Case A uses 15 kHz subcarrier spacing. SSB
% patterns Case B and Case C use 30 kHz subcarrier spacing.
if strcmp(ssbPattern, "Case A")   % Class A pattern is the 0 in Simulink
    scsSSB = 15;
else
    scsSSB = 30;
end

%%
% Resample the signal to 7.68e6, the sampling rate required at the input to
% the detector.
Fs_in = 7.68e6;
signalIn = resample(rxWaveform_scaled, Fs_in, Fs_rxWaveform); % input signal that is required

%%
% Define constants for detector implementation.
Fs_30 = 7.68e6;  % Sampling frequency for 30 kHz subcarrier spacing (=Fs_in)
Fs_15 = 3.84e6;  % Sampling frequency for 15 kHz subcarrier spacing
Fc_15 = 120 * 15e3;

Nfft = 256;      % FFT size (SSB occupies 240 subcarriers)


%The below Function is equivalent to the block SSB Detect and Demod
fprintf('Running MATLAB signal detection and demodulation code\n'); % after half band filter

[dataOut] =  detectPSSandRecoverSSB(signalIn, Fc_15, Fs_15,Fs_30,Fs_in, Nfft, scsSSB,Lmax);
figure;
imagesc(abs(dataOut));
title('MATLAB SSB Grid')
ylabel('Subcarrier');
xlabel('OFDM Symbol');
            %%
            % Decode the MIB from the MATLAB SSB grid to further verify data
            % recovered from the signal. If the bchCRC returned is 0 this indicates no
            % errors were found.
fprintf('Decoding MIB from MATLAB SSB grid \n');

%if bchCRC == 0
 %   fprintf('MIB decode successful\n');
  %  disp([' Cell identity: ' num2str(nCellID)]);
%else
 %   fprintf('MIB decode failed, bchCRC was non-zero\n')
%end
%fprintf('Decoding MIB from MATLAB SSB grid \n');


