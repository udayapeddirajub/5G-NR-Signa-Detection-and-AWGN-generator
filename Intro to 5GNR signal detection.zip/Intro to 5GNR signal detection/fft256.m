function y = fft256(x)
    % Compute 256-point FFT using 64-point FFT
  % x = sfi(x,14,0);

% Create a 64-point FFT object
fft64 = dsphdl.FFT(FFTLength=64);

% Input sequence of length 256

% Perform 256-point FFT using 64-point FFT function
y = zeros(256, 1);
for i = 1:4
    % Divide the input sequence into four 64-point sub-sequences
    sub_seq = x((i-1)*64 + 1 : i*64);
    
    % Apply the 64-point FFT function to each sub-sequence
    sub_fft = fft64(sub_seq, true);
    
    % Store the results in the output sequence
    y((i-1)*64 + 1 : i*64) = sub_fft;
end
end
    