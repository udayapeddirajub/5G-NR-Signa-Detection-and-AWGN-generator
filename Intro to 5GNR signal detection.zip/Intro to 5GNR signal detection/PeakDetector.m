function peakLocations = PeakDetector(psscorr_mag_sq, threshold, window_length)
    % Find correlation values that exceed the threshold
    aboveThreshold = psscorr_mag_sq > threshold;

    % Find the indices of the peaks
    peakIndices = find(aboveThreshold);

    % Initialize the peakLocations array
    peakLocations = zeros(numel(peakIndices), 1);

    % Iterate over the peak indices
    for i = 1:numel(peakIndices)
        % Get the current peak index
        currentIndex = peakIndices(i);

        % Define the window around the current peak index
        windowStart = max(1, currentIndex - window_length);
        windowEnd = min(numel(psscorr_mag_sq), currentIndex + window_length);

        % Find the maximum value within the window
        [maxValue, maxIndex] = max(psscorr_mag_sq(windowStart:windowEnd));

        % Adjust maxIndex to account for the window offset
        maxIndex = maxIndex + windowStart - 1;

        % Add the peak location to the peakLocations array
        peakLocations(i) = maxIndex;
    end

    % Transpose the peakLocations array to make it a column vector
    %peakLocations = peakLocations.';
end