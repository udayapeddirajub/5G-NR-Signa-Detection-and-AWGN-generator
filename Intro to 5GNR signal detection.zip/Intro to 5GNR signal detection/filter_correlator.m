function output = filter_correlator(coefficients, denominator, input)
    % Length of the input signal
    N = length(input);

    % Length of the filter coefficients
    M = length(coefficients);

    % Initialize the output signal
    output = complex(zeros(N, 1));

    % Filter state variables
    state = complex(zeros(M, 1));

    % Perform the correlation operation
    for n = 1:N
        % Update filter state
        state(2:M) = state(1:M-1);
        state(1) = input(n);

        % Perform filtering
        output(n) = sum(coefficients .* state) / denominator;
    end
end