function grid = OFDMDemodulate(carrier, waveform, SampleRate, Nfft, scs, nrb)
    if nargin < 6
        CyclicPrefixFraction = 0.5;
    end
    nrb = carrier.NSizeGrid;
    scs = carrier.SubcarrierSpacing;    
    mu = floor(scs / 15) - 1;
%    if strcmp(carrier.CyclicPrefix, 'normal')
        N_cp1 = floor(((144) * 2^(-mu) + 16) * (SampleRate / 30720000));
        N_cp2 = floor((144 * 2^(-mu)) * (SampleRate / 30720000));
 %   else
   %     N_cp1 = floor((512 * 2^(-mu)) * (SampleRate / 30720000));
  %      N_cp2 = N_cp1;
    %end

    idx = 1;
    slot = 0;
    grid = complex(zeros(nrb * 12, 0));
    sample_pos_in_slot = 0;
    
    while idx + Nfft <= numel(waveform)
        if slot == 0 || slot == 7 * 2^mu
            cp = N_cp1;
        else
            cp = N_cp2;
        end
        slot = mod(slot + 1, 7 * 2^mu);
        cp_advance = floor(CyclicPrefixFraction * cp);
        idx = idx + cp_advance;
        symbol_t = waveform(idx:idx + Nfft - 1);
        %fftNfft = dsphdl.FFT(FFTLength=Nfft);
        symbol_f = fftshift(fft(symbol_t));


        
        % Compute theta values for the exponential functions
        %theta1 = 2*pi*(cp - cp_advance)/Nfft*(0:numel(symbol_t)-1).';
        %theta2 = pi*(cp - cp_advance);
        %cp_offset = (cp - cp_advance) / (SampleRate/(scs*1000));
        %        CarrierFrequency = scs * 1000 / 2 + cp_offset ;
        %theta3 = 2 * pi * CarrierFrequency / SampleRate * sample_pos_in_slot;
        %theta1 = theta1 * (pi/180);
        
        %theta2 = theta2 * (pi/180);
        
        %theta3 = theta3 * (pi/180);
        
        % Compute the exponentials using cordiccexp
        %exp1 = cordiccexp(theta1);
        %exp2 = cordiccexp(theta2);
        %exp3 = cordiccexp(theta3);
        
        % Apply the exponential functions to symbol_f
        %symbol_f = symbol_f .* exp1;
        %symbol_f = symbol_f .* exp2;
        %symbol_f = symbol_f(Nfft/2 - nrb*12/2 + 1 : Nfft/2 + nrb*12/2);
        %symbol_f = symbol_f .* exp3;
        
        % Update the range of symbol_f
        %symbol_f = symbol_f(Nfft/2 - nrb*12/2 + 1 : Nfft/2 + nrb*12/2);


        
        symbol_f = symbol_f .* exp(1j*2*pi*(cp - cp_advance)/Nfft*(0:numel(symbol_t)-1).');
        symbol_f = symbol_f .* exp(1j*pi*(cp - cp_advance));
        
        symbol_f = symbol_f(Nfft/2 - nrb*12/2 + 1 : Nfft/2 + nrb*12/2);
        
        % Calculate carrier frequency
        cp_offset = (cp - cp_advance) / (SampleRate/(scs*1000));
        CarrierFrequency = scs * 1000 / 2 + cp_offset ;
        
        symbol_f = symbol_f .* exp(1j * 2 * pi * CarrierFrequency / SampleRate * sample_pos_in_slot);
        sample_pos_in_slot = sample_pos_in_slot + Nfft;
        
        grid = [grid, symbol_f];
        
        idx = idx + Nfft + (cp - cp_advance);
    end
end