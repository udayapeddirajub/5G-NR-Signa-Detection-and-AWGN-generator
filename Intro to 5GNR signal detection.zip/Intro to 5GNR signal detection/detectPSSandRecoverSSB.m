function [dataOut] = detectPSSandRecoverSSB(signalIn,Fc_15,Fs_15, Fs_30,Fs_in, Nfft, scsSSB,Lmax)
            dataOut = []; % added default value for dataOut



            % The detector uses a halfband filter to reduce sample rate from the input
            % sampling rate of 7.68 MHz to 3.84 MHz. The detector uses the sample
            % rate 7.68 MHz for subcarrier spacing 30 kHz, and 3.84 MHz for subcarrier
            % spacing 15 kHz.
            %TransitionWidth = Fs_15 - 2*Fc_15;
           % StopbandAttenuation = 60;
            %scs15halfband = FIRHalfbandDecimator(TransitionWidth, StopbandAttenuation, Fs_in, Fc_15);
            scs15halfband = dsp.FIRHalfbandDecimator(...
            'Specification',       'Transition width and stopband attenuation', ...
            'TransitionWidth',     Fs_15 - 2*Fc_15, ...
            'StopbandAttenuation', 60, ...
            'SampleRate',          Fs_in);
            
            halfband_grpDelay = grpdelay(scs15halfband,2);
            halfband_transient = ceil(halfband_grpDelay(2)/2);
            
            %% MATLAB Reference Implementation of Signal Detection and Demodulation
            % Run the MATLAB implementation of the signal detection and demodulation
            % algorithm and display the locations of the PSS peaks located in the
            % waveform.
            
            
            %%
            % If the subcarrier spacing of the SSB is 15 kHz the input signal is
            % downsampled by 2 using a halfband filter to reduce the sampling rate from
            % 7.68 MSPS (|Fs_30|) to 3.84 MSPS (|Fs_15|). For 30 kHz subcarrier spacing no
            % sampling rate change is required as the sample rate of the input signal
            % (|Fs_in|) matches the sample rate required to process the signal (|Fs_30|).
            % This functionality is implemented by the |nrhdlSignalDetection/SSB Detect
            % and Demod/scsSelection| subsystem in the Simulink model.
                
           if scsSSB == 15
               Fs_correlator = Fs_15;
               halfbandOut = scs15halfband(signalIn); % decimation  to 15KHz to reduce the sampling frequecny based on scs
               correlatorIn = halfbandOut(halfband_transient:end); %transient removal
               %correlatorIn = signalIn;

           else
               Fs_correlator = Fs_30;      % Fs_30 == Fs_in
               correlatorIn = signalIn;
           end
            
            % PSS Detector block
            % Get correlation filter coefficients for the 3 PSS sequences.

            pssCorrelationCoeffs = getCorrelationCoeffs(Nfft);
            psscorr      = complex(zeros(length(correlatorIn), 3));


            psscorr(:,1) = filter_correlator(pssCorrelationCoeffs(:,1), 1, correlatorIn);
            psscorr(:,2) = filter_correlator(pssCorrelationCoeffs(:,2), 1, correlatorIn);
            psscorr(:,3) = filter_correlator(pssCorrelationCoeffs(:,3), 1, correlatorIn);
            

            psscorr_mag_sq = abs(psscorr).^2; % implements corrMag0, corrMag1 and corrMag2 of Simulink Model

            %4th channel for general square magnitude

            energyFilt  = ones(Nfft,1);   %just a matrix

            sig_mag_sq  = abs(correlatorIn).^2; % signal magnitude
            %length(sig_mag_sq)
            sigEnergy   = filter_correlator(energyFilt,1, sig_mag_sq); %- signal Energy is one of the inputs to the multiplier and the amplifier
            
            % Calculate threshold for correlation values from signal energy.
            minimumThreshold  = Nfft*(2^-12)^2;          % Set minimumThreshold to avoid triggering on noise
            PSSThreshold_dB  = -6;                       % Strength threshold in dBs (0 is least sensitive).
            thresholdScaling = 10^(PSSThreshold_dB/10);  % Threshold scaling factor 
            threshold = sigEnergy.*thresholdScaling;     % Calculate the threshold using the signal power and threshold scaling factor
            threshold(threshold<minimumThreshold) = minimumThreshold; % Apply minimum threshold value where calculated threshold is lower than the minimum
            %%
           % Plot of PSS Vs Threshold
            figure;
            plot(psscorr_mag_sq,'.-');
            hold on;
            plot(threshold);
            legend('PSS 0','PSS 1','PSS 2','Threshold');
            title('MATLAB correlator outputs and threshold');
            %psscorr_mag_sq is the correlation output in model
            window_length=11;
            [locations_1] = PeakDetector(psscorr_mag_sq(:,1), threshold, window_length);
            [locations_2] = PeakDetector(psscorr_mag_sq(:,2), threshold, window_length);
            [locations_3] = PeakDetector(psscorr_mag_sq(:,3), threshold, window_length);
            % Combine all of the locations into a single vector and check that some
            % peaks were fou% Demod/PSS Detector/Find Peak/register PSS ID| in the Simulink model.
            ml_locations = [locations_1 locations_2 locations_3];% it is equivalent to the locationPeaks signal in the Simulink model
            
            if isempty(ml_locations)
                fprintf('No correlation peaks found \n');
                return;
            end
            selectedPeak = min(ml_locations);
            [~,pssCorrNumber] = max(psscorr(selectedPeak,:));
            ml_nCellID2 = pssCorrNumber-1; %ends the register PSS ID block here
           
            % Equivalent Demod/OFDM Demodulator| subsystem.
            
            
            pssSymbolStart = selectedPeak-(Nfft+18-1);
            if pssSymbolStart<1
                fprintf('The detected PSS peak is from a partial SSB at the start of the signal. The start of the SSB is missing from waveform, and the SSB cannot be demodulated.\n');
                return;
            end
            nrDemodSymbolEnd = pssSymbolStart + 4*(Nfft+18); % SSB is 4 OFDM symbols long
            
            % Check values of pssSymbolStart and nrDemodSymbolEnd
            if pssSymbolStart >= nrDemodSymbolEnd-1
                return;
            end
            pssStart = pssSymbolStart(1);

            % Extract scalar value from nrDemodSymbolEnd
            demodEnd = nrDemodSymbolEnd(1);

            ssbOFDMInput = complex(zeros(1096,1));
            %demodEnd-pssStart
            % Loo
            % p through values of i
            for i = pssStart:demodEnd-1
                ssbOFDMInput(i - pssStart + 1) = correlatorIn(i);
            end

            %%
            % The nrOFDMDemodulate function requires input data starting at a slot
            % boundary, which is one OFDM symbol before the start of the SSB. The first
            % OFDM symbol in the slot has a different cyclic prefix length of either 20
            % for SSB subcarrier spacing of 15 kHz, or 22 for SSB subcarrier spacing of
            % 30 kHz. The 
            % starting point of demodulation is adjusted to account for this. This
            % additional offset is not required in the Simulink implementation as OFDM
            % Demodulator block does not have the requirement to start on a slot boundary.
            if scsSSB == 15
               slotFirstCyclicPrefix = 20;
            else
                slotFirstCyclicPrefix = 22;
            end

            nrDemodSymbolPad = zeros(Nfft+slotFirstCyclicPrefix,1);% why not equal size to the ssbOFDMInput
            %length(nrDemodSymbolPad)
          %  length(ssbOFDMInput)
            nrDemodSignalIn = [nrDemodSymbolPad; ssbOFDMInput];
            carrier = nrCarrierConfig('SubcarrierSpacing',scsSSB,'NSizeGrid',20);
            
            grid = nrOFDMDemodulate(carrier,nrDemodSignalIn,'SampleRate',Fs_correlator,'Nfft',256);%OFDMDemodulate(carrier, nrDemodSignalIn, Fs_correlator, Nfft); %Equivalent to the OFDM Demodulator Block in the Simulink model
          
            % |ml_SSBGrid|.
            ml_SSBGrid = grid(:,2:5);
                       
            %%
            % Get the IQ samples that cover the SSB region, prior to OFDM demodulation.
            % This is equivalent to the input to the OFDM Demodulator in the Simulink
            % model, |sl_SSBRawIQ|.
            ml_SSBRawIQ = nrDemodSignalIn(Nfft+slotFirstCyclicPrefix+1:end);
            
            fprintf('MATLAB signal detection and demodulation complete\n');
            
            %%
            % Display MATLAB peak locations and nCellID2.
            fprintf('MATLAB Peak Location(s) \n');
            fprintf('    %i \n',ml_locations);
            
            fprintf('MATLAB nCellID2 = %i\n', ml_nCellID2);
            dataOut = ml_SSBGrid;
            %%
            % Plot demodulated SSB grid from Simulink output signals.
            
            [mibStruct, nCellID, ssbIndex, bchCRC] = mibDecode(dataOut, ml_nCellID2, Lmax);
            
            

            
end
